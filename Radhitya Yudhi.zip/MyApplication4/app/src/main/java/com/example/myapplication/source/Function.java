package com.example.myapplication.source;

import android.content.Context;

public class Function {


    public static void showMessage(Context context, String message){






    }
}
