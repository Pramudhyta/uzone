package com.example.myapplication.source;

public class Apis {

    public final static  String homePage="https://uzone.id/api/get_homepage";
    public final static String TAG_HOMEPAGE="MyHome";
}
