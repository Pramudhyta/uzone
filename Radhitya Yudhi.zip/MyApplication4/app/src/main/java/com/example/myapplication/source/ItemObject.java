package com.example.myapplication.source;

public class ItemObject {
    public int type;
    public Object object;

    public ItemObject(int type, Object object) {
        this.type = type;
        this.object = object;
    }
}
